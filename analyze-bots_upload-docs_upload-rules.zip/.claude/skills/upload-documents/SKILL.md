---
name: upload-documents
description: "Channel.io Desk API에 RAG 문서(Markdown 파일)를 일괄 업로드한다. x-account 인증 방식."
user-invocable: true
argument-hint: "<docs_dir> <channel_id> <x_account> [space_id]"
---

# Upload Documents

`06_rag_documents/` 디렉터리의 Markdown 파일을 Channel.io RAG 문서로 일괄 업로드합니다.

## 인자

| 위치 | 이름 | 필수 | 설명 | 기본값 |
|------|------|------|------|--------|
| `$0` | `docs_dir` | O | Markdown 파일이 있는 디렉터리 | — |
| `$1` | `channel_id` | O | 채널 ID | `230196` |
| `$2` | `x_account` | O | 인증 토큰 (`x-account`) | — |
| `$3` | `space_id` | X | 스페이스 ID | `17872` |

## Steps

1. Parse `$ARGUMENTS`. Ask for missing required values.
2. Run the uploader:
   ```bash
   python3 .claude/skills/upload-documents/upload_documents.py \
       --dir <docs_dir> \
       --channel-id <channel_id> \
       --x-account <x_account> \
       --space-id <space_id>
   ```
3. Report success/failure counts to the user.

**Language:** Detect the language from the user's first message and respond in that language throughout. Support Korean (한국어) and Japanese (日本語). Default to Korean if language is unclear.
