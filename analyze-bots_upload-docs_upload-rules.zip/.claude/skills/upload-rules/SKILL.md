---
name: upload-rules
description: "Channel.io ALF 규칙 파일(Markdown)을 일괄 업로드한다. x-account 인증 방식."
user-invocable: true
argument-hint: "<rules_dir> <channel_id> <x_account>"
---

# Upload Rules

`rules/` 디렉터리의 Markdown 파일을 Channel.io ALF 규칙으로 일괄 업로드합니다.

## 인자

| 위치 | 이름 | 필수 | 설명 |
|------|------|------|------|
| `$0` | `rules_dir` | O | 규칙 Markdown 파일이 있는 디렉터리 |
| `$1` | `channel_id` | O | 채널 ID |
| `$2` | `x_account` | O | 인증 토큰 (`x-account`) |

## Steps

1. Parse `$ARGUMENTS`. Ask for missing required values.
2. Run the uploader:
   ```bash
   python3 .claude/skills/upload-rules/upload_rules.py \
       --dir <rules_dir> \
       --channel-id <channel_id> \
       --x-account <x_account>
   ```
3. Report success/failure counts to the user.

**Language:** Detect the language from the user's first message and respond in that language throughout. Support Korean (한국어) and Japanese (日本語). Default to Korean if language is unclear.
