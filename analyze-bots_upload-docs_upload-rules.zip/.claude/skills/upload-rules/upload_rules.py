#!/usr/bin/env python3
"""Channel.io ALF Rules - 규칙 일괄 업로드"""

import json
import os
import re
import sys
import time
import urllib.request
import urllib.error


def strip_md(text):
    """Markdown을 plain text로 변환"""
    lines = text.split("\n")
    cleaned = []
    for line in lines:
        if line.strip().startswith(">"):
            content = re.sub(r"^>\s?", "", line)
            if content.strip():
                cleaned.append(content)
            continue
        if line.strip() in ("---", "***", "___"):
            continue
        cleaned.append(line)
    result = "\n".join(cleaned)
    result = re.sub(r"\*\*([^*]+)\*\*", r"\1", result)  # bold
    result = re.sub(r"\*([^*]+)\*", r"\1", result)  # italic
    result = re.sub(r"`([^`]+)`", r"\1", result)  # code
    result = re.sub(r"^#{1,6}\s+", "", result, flags=re.MULTILINE)  # sub headings
    return result.strip()


def main():
    if len(sys.argv) < 4:
        print("Usage: python3 upload_rules.py <rules_dir> <channel_id> <x_account>")
        sys.exit(1)

    rules_dir = sys.argv[1]
    channel_id = sys.argv[2]
    x_account = sys.argv[3]

    ALF_HOST = "https://front-alf-desk-api.channel.io"
    headers = {
        "x-account": x_account,
        "Cookie": f"x-account={x_account}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    files = sorted([f for f in os.listdir(rules_dir) if f.endswith(".md")])

    print("━" * 55)
    print(f" 규칙 업로드 → channel {channel_id} | {len(files)}개 파일")
    print("━" * 55)

    success = 0
    fail = 0

    for idx, fname in enumerate(files, 1):
        path = os.path.join(rules_dir, fname)
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

        # Extract title from first # line
        title_match = re.search(r"^#\s+(.+)$", content, re.MULTILINE)
        title = title_match.group(1).strip() if title_match else fname.replace(".md", "")

        # Remove the first # title line and get instruction
        instruction_text = re.sub(r"^#\s+.+\n?", "", content, count=1)
        instruction = strip_md(instruction_text)

        payload = json.dumps({
            "trigger": "always",
            "title": title,
            "instruction": instruction,
            "state": "live"
        }, ensure_ascii=False).encode("utf-8")

        url = f"{ALF_HOST}/desk/channels/{channel_id}/front-alf/v2/rules"
        req = urllib.request.Request(url, data=payload, headers=headers, method="POST")

        try:
            resp = urllib.request.urlopen(req)
            data = json.loads(resp.read().decode("utf-8"))
            rule_id = data.get("frontAlfRule", {}).get("id", "?")
            print(f"  [{idx:2d}/{len(files)}] ✅ {title}  (id={rule_id})")
            success += 1
        except urllib.error.HTTPError as e:
            err = e.read().decode("utf-8")[:150] if e.fp else str(e)
            print(f"  [{idx:2d}/{len(files)}] ❌ {title}  ({e.code}: {err})")
            fail += 1
        except Exception as e:
            print(f"  [{idx:2d}/{len(files)}] ❌ {title}  ({e})")
            fail += 1

        time.sleep(0.3)

    print()
    print("━" * 55)
    print(f" 완료: {success}개 성공" + (f", {fail}개 실패" if fail else ""))
    print("━" * 55)


if __name__ == "__main__":
    main()
