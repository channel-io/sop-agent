---
name: analyze-bots
description: "Non-ALF 봇 행동 분석. messages.csv 또는 Excel에서 봇 유형·커버리지·에스컬레이션 패턴을 분석하고 JSON + Markdown 리포트를 생성한다."
user-invocable: true
argument-hint: "--messages <path> | --excel <path> [--tags <path>] [--output <dir>]"
---

# Bot Analyzer

Non-ALF 봇 메시지를 추출해 봇 유형, 커버리지, 에스컬레이션 패턴, Admin 연동을 분석합니다.

## 인자

| 인자 | 필수 | 설명 |
|------|------|------|
| `--messages` | 조건부 | `01_clustering/{prefix}_messages.csv` 경로 |
| `--excel` | 조건부 | 원본 Excel (Message data 시트) — messages 없을 때 사용 |
| `--tags` | X | `01_clustering/{prefix}_tags.xlsx` |
| `--output` | X | 출력 디렉토리 (기본: `results/{name}/bot_analysis`) |

`--messages` 또는 `--excel` 중 하나는 필수입니다.

## Steps

1. Parse `$ARGUMENTS` and identify input paths.
2. Run the analyzer:
   ```bash
   python3 .claude/skills/analyze-bots/analyze_bots.py \
       --messages <path> \
       --output <output_dir>
   ```
3. Report output file locations to the user.

## Output

- `bot_analysis.json` — 분석 데이터
- `bot_analysis_report.md` — 리포트

**Language:** Detect the language from the user's first message and respond in that language throughout. Support Korean (한국어) and Japanese (日本語). Default to Korean if language is unclear.
